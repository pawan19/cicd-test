#!/bin/bash
sudo service apache2 start

