#!/bin/bash
sudo service apache2 stop

