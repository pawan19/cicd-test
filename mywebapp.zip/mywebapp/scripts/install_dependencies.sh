#!/bin/bash
sudo apt-get install apache2

